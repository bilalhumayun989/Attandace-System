const mongoose = require('mongoose');

const shiftSessionSchema = new mongoose.Schema({
    checkIn: { type: Date },
    checkOut: { type: Date },
    // Boundary entries allocate hours; they are not device punches.
    checkInSource: { type: String, enum: ['fingerprint', 'boundary'] },
    checkOutSource: { type: String, enum: ['fingerprint', 'boundary', 'automatic'] },
    sessionStart: { type: Date }, // original IN shared by both workday segments
    duration: { type: Number, default: 0 }, // in minutes
    missed: { type: Boolean, default: false }, // true = employee checked in but never checked out
}, { _id: false });

const attendanceSchema = new mongoose.Schema(
    {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        },
        date: {
            type: String, // YYYY-MM-DD
            required: true,
        },
        checkIn: {
            type: Date,
        },
        checkOut: {
            type: Date,
        },
        checkInSource: { type: String, enum: ['fingerprint', 'boundary'] },
        checkOutSource: { type: String, enum: ['fingerprint', 'boundary', 'automatic'] },
        duration: {
            type: Number, // in minutes — total for the day (sum of all shifts)
            default: 0,
        },
        // Array of individual shift sessions for this day
        shifts: {
            type: [shiftSessionSchema],
            default: [],
        },
        employee: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
        action: {
            type: String,
        },
        status: {
            type: String,
            enum: ['Present', 'Late', 'Absent', 'Short Hours', 'On Leave', 'checked_in', 'checked_out'],
            default: 'Present',
        },
        isCheckingOut: {
            type: Boolean,
            default: false,
        },
        overtimeIn: {
            type: Date,
        },
        overtimeOut: {
            type: Date,
        },
        overtimeStatus: {
            type: String,
            enum: ['None', 'Pending', 'Approved', 'Rejected'],
            default: 'None',
        },
        overtimeRejectReason: {
            type: String,
        },
        isAutoLeave: {
            type: Boolean,
            default: false,
        },
        markedByFace: {
            type: Boolean,
            default: false,
        },
        isCustom: {
            type: Boolean,
            default: false,
        },
        // Ids of kiosk scans saved on this record (fingerprint kiosk, incl. offline sync).
        // Lets the server ignore a scan that is sent a second time. Absent on all other records.
        clientIds: {
            type: [String],
            default: undefined,
        },
        adminId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        }
    },
    {
        timestamps: true,
        optimisticConcurrency: true,
    }
);

// Compound index to ensure one attendance record per user per day
attendanceSchema.index({ userId: 1, date: 1 }, { unique: true });

// Fast "was this kiosk scan already saved?" lookup (only records that have clientIds are indexed)
attendanceSchema.index({ userId: 1, clientIds: 1 }, { sparse: true });

const Attendance = mongoose.model('Attendance', attendanceSchema);

module.exports = Attendance;
